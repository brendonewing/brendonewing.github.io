﻿/* Brendon Ewing
 * September 18
 */
using System;
using static System.Console;

namespace ArrayDemo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] pract = new double[4];
            pract[0] = 13.00;
            pract[1] = 17.35;
            pract[2] = 19.12;
            pract[3] = 22.45;

            for (int i = 0; i < 4; i++)
                WriteLine(pract[i].ToString("C"));
        }
    }
}
