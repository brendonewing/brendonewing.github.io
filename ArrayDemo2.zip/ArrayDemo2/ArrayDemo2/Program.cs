﻿/* Brendon Ewing
 * September 18
 */
using System;
using static System.Console;

namespace ArrayDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] pract = new int[8];
            string userInp;

            Write("Enter your score on test 1 ");
            userInp = ReadLine();
            pract[0] = Convert.ToInt32(userInp);

            Write("Enter your score on test 2 ");
            userInp = ReadLine();
            pract[1] = Convert.ToInt32(userInp);

            Write("Enter your score on test 3 ");
            userInp = ReadLine();
            pract[2] = Convert.ToInt32(userInp);

            Write("Enter your score on test 4 ");
            userInp = ReadLine();
            pract[3] = Convert.ToInt32(userInp);

            Write("Enter your score on test 5 ");
            userInp = ReadLine();
            pract[4] = Convert.ToInt32(userInp);

            Write("Enter your score on test 6 ");
            userInp = ReadLine();
            pract[5] = Convert.ToInt32(userInp);

            Write("Enter your score on test 7 ");
            userInp = ReadLine();
            pract[6] = Convert.ToInt32(userInp);

            Write("Enter your score on test 8 ");
            userInp = ReadLine();
            pract[7] = Convert.ToInt32(userInp);

            WriteLine("----------------------------");

            WriteLine("Scores in original order:\n {0} {1} {2} {3} {4} {5} {6} {7}", pract[0], pract[1], pract[2], pract[3], pract[4], pract[5], pract[6], pract[7]);

            WriteLine("----------------------------");

            for (int i = 0; i < 8; i++)
                

            
        }
    }
}
